// JavaScript Document
$('#banner').owlCarousel({
    loop:true,
	items:1,
    autoplay:true,
    autoplayTimeout:5000,  
    nav:true,

	  })

/*$('#ca2').owlCarousel({
    loop:true,
    margin:20,
   nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:6
        }
    }
})*/